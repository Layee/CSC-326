//  Created by Frank M. Carrano and Timothy M. Henry.
//  Copyright (c) 2017 Pearson Education, Hoboken, New Jersey.

void goodFunction()
{
   double boxValue = 4.321;           // Original statement
   GoodMemory gmObject;               // Create a safe memory object
   gmObject.unleakyMethod(boxValue);  // Perform the task
}  // end goodFunction